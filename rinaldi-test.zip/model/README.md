# Model

This project contains all the model classes used across in different projects
